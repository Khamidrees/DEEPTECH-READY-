# Fake product detector
